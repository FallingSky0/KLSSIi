<!DOCTYPE html>
<html lang="en">
<head>
<title>Payroll System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Bookman Old Style", sans-serif; color: #000; font-weight: bold;}
body {font-size:16px; background-color: #000; color: #000; background-image: url('images/background.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.form-container {
    background-color: rgba(128, 128, 128, 0.8); /* Transparent gray background */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.form-container h2, .form-container label {
  color: #333;
}

.form-container input {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

.form-container input[type="submit"] {
  background-color: #f7bf16;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.form-container input[type="submit"]:hover {
  background-color: #e0aa00;
}

/* Style for input fields side by side */
.form-container .input-group {
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
}

.form-container .input-group label {
  width: 48%;
  text-align: right;
  margin-bottom: 5px;
}

.form-container .input-group input {
  width: 48%;
  margin-bottom: 10px;
}
</style>
</head>
<body>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-black w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
    <div class="w3-container w3-dark-grey">
    <h4>Menu</h4>
    </div>
  
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
    
      
  </div>
  <div class="w3-bar-block">
      
      <dl>
          <dt><a href="home.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a> </dt>
          
          <dt><a href="employee.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white w3-yellow">Employee</a></dt>
          <dt><a href="employee-payment.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Payment Parameters</a></dt>
          <dt><a href="employee-payslip.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Pay slip</a></dt>
          <dt><a href="employee-setsalary.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Set salary</a></dt>
          <dt><a href="employee-payhistory.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Payment history</a></dt>
          
</dl>
     
  </div>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
  <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()">☰</a>
  <span>Payroll system</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:290px;margin-right:-10px;margin-top: -5px;margin-bottom: 0px">
  
  <!-- Header -->
  
  
  <div class="w3-container" style="padding: 50px 200px 20px 200px">
    <div class="container">
      <div class="form-container">
        <h2 style="text-align: center;">Enter User Information</h2>
        <form action="save_user.php" method="post">
          <div class="input-group">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name"><br><br>
          </div>
          <div class="input-group">
            <label for="id"> ID:</label><br>
            <input type="text" id="id" name="id"><br><br>
          </div>
          <div class="input-group">
            <label for="username">Username:</label><br>
            <input type="text" id="username" name="username"><br><br>
          </div>
          
          <div class="input-group">
            <label for="role">Role:</label><br>
            <input type="text" id="role" name="role"><br><br>
          </div>
          <div class="input-group">
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email"><br><br>
          </div>
          <div class="input-group">
            <label for="age">Age:</label><br>
            <input type="number" id="age" name="age"><br><br>
          </div>
          <input type="submit" value="Submit">
        </form>
      </div>
    </div>
  </div>
</div>


<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}
</script>

</body>
</html>