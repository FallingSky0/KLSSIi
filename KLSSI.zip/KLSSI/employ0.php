<!DOCTYPE html>
<html>
<head>
    <title>KLSSI</title>
    <link rel="icon" type="image/png" href="images/favicon.png">
    <style>
        body {
            background-image: url("images/background.jpg");
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Arial', sans-serif;
            color: white;
            text-align: center;
        }

        .container {
            max-width: 600px;
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(0, 0, 0, 0.7);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .image {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
            margin-bottom: 5px;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            background-color: #1a1a1a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #F7Bf16;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="images/payroll.png" class="image" alt="Image">
        <h2>Welcome to King's Legion Security Service INC.</h2>
        <a href="employ.php" class="button"> Employee</a>
    </div>
</body>
</html>