<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login to KLSSI</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="images/favicon.png">
    <style>
        body {
            background-image: url('images/background.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: 'Arial', sans-serif;
            color: white;
            text-align: center;
        }

        .header {
            text-align: center;
            margin-top: 40px; /* Add margin-top to move the image down */
            position: absolute; /* Position the image absolutely */
            top: 0; /* Place the image at the top of the page */
            left: 50%; /* Center the image horizontally */
            transform: translateX(-50%); /* Adjust to center horizontally */
        }

        .header img {
            max-width: 25%;
            height: auto;
        }

        .loginbox {
            text-align: center;
            background: rgba(255, 255, 255, 0.8); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); 
        }

        /* Style for adjusting the size of the favicon */
        link[rel="icon"] {
            width: 32px;
            height: 32px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="images/payroll.png" alt="Payroll Image">
    </div>
    <div class="loginbox">
        <h3>Log in to here</h3>
        
        <form method="post" action="newfile.php">
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Your Username">
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password">
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</body>
</html>