<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Parameter</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/w3.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif; /* Use a formal font */
            background-color: #f2f2f2; /* Light gray background */
            background-image: url('images/background.jpg'); /* Replace with your background image */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-size: 16px; /* Default font size */
        }

        .w3-half img {
            margin-bottom: -6px;
            margin-top: 6px;
            opacity: 0.8;
            cursor: pointer;
        }

        .w3-half img:hover {
            opacity: 1;
        }

       
        .content {
            margin-left: 320px; /* Adjust for sidebar width */
            padding: 20px;
            transition: margin-left 0.3s;
        }

        .form-container {
            background-color: rgba(128, 128, 128, 0.8); /* Transparent gray background */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 50 auto; /* Center the form container */
            width: 70%; /* Adjust width as needed */
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 16px; /* Adjust font size as needed */
            color: #333; /* Darker text for contrast */
        }

        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        input[type="submit"] {
            background-color: #f7bf16; /* Orange button color */
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #e0aa00; /* Darker orange on hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2; /* Light gray for table header */
        }
    </style>
</head>
<body>

  <!-- Sidebar/menu -->
<nav class="w3-sidebar w3-black w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
    <div class="w3-container w3-dark-grey">
    <h4>Menu</h4>
    </div>
  
    
    </div>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
    
      
  </div>
  <div class="w3-bar-block">
      
      <dl>
          <dt><a href="home.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a> </dt>
  
          <dd></dd>
    <dt><a href="employee.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white ">  Employee  </a></dt>
          
          <dt><a href="employee-payment.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white w3-yellow">Payment Parameters</a> </dt>
          <dt><a href="employee-payslip.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Pay slip</a> </dt>
         
          <dt><a href="employee-payhistory.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white ">Payment history</a> </dt>
            <dt><a href="logout.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Log Out</a> </dt>
          
          
          
          
</dl> 
    
  </div>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
  <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()">☰</a>
  <span>Payroll system</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
  <div class="w3-main" style="margin-left:290px;margin-right:-10px;margin-top: -5px;margin-bottom: 0px">

  <!-- Header -->
       <div class="w3-container">
            <h4></h4>
            <br><br>
           
        </div>
      
    <div class="content">
       
        <main>
            <article>
                <div class="form-container">
                    <form method="post" action="process_payroll.php">
                        <table>
                            <tr>
                                <th>Employee ID:</th>
                                <td>
                                    <select name="id">
    <?php
    // Database connection details (replace with your actual details)
    $servername = "localhost";
    $username = "your_username";
    $password = "your_password";
    $dbname = "payroll";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch employee IDs and names from the database
    $sql = "SELECT id, name FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<option value='" . $row["id"] . "'>" . $row["id"] . " - " . $row["name"] . "</option>";
        }
    } else {
        echo "<option value=''>No employees found</option>";
    }

    // Close the database connection
    $conn->close();
    ?>
</select>
                                </td>
                            </tr>
                            <tr>
                                <th>Month:</th>
                                <td>
                                    <select name="month">
                                        <option value="January">January</option>
                                        <option value="February">February</option>
                                        <option value="March">March</option>
                                        <option value="April">April</option>
                                        <option value="May">May</option>
                                        <option value="June">June</option>
                                        <option value="July">July</option>
                                        <option value="August">August</option>
                                        <option value="September">September</option>
                                        <option value="October">October</option>
                                        <option value="November">November</option>
                                        <option value="December">December</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>Holidays (Number of Days):</th>
                                <td><input type="number" name="holidays" value="0" min="0"></td>
                            </tr>
                            <tr>
                                <th>Bonus (Number of Days):</th>
                                <td><input type="number" name="bonus" value="0" min="0"></td>
                            </tr>
                            <tr>
                                <th>Overtime (Hours):</th>
                                <td><input type="number" name="o_t" value="0" min="0"></td>
                            </tr>
                            <tr>
                                <th>Rate Per Day:</th>
                                <td><input type="number" name="rateperday" value="610" readonly></td>
                            </tr>
                            <tr>
                                <th>Days of Work:</th>
                                <td><input type="number" name="days_of_work" value="0" min="0"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" value="Calculate & Save"></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </article>
        </main>
    </div>

    <script>
        // Script to open and close sidebar
        function w3_open() {
            document.getElementById("mySidebar").style.display = "block";
            document.getElementById("myOverlay").style.display = "block";
        }

        function w3_close() {
            document.getElementById("mySidebar").style.display = "none";
            document.getElementById("myOverlay").style.display = "none";
        }

        // Modal Image Gallery
        function onClick(element) {
            document.getElementById("img01").src = element.src;
            document.getElementById("modal01").style.display = "block";
            var captionText = document.getElementById("caption");
            captionText.innerHTML = element.alt;
        }
    </script>

</body>
</html>