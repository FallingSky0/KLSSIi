<?php
// Connect to your database
$conn = new mysqli("localhost", "username", "password", "payroll");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$employee_id = $_POST["id"];
$month = $_POST["month"];
$holidays = $_POST["holidays"];
$bonus = $_POST["bonus"];
$o_t = $_POST["o_t"];
$rateperday = $_POST["rateperday"];
$days_of_work = $_POST["days_of_work"];

// Calculate total salary
$total = ($holidays * 610) + ($bonus * 18300) + ($o_t * 76) + ($days_of_work * $rateperday);

// Round the total to 2 decimal places
$total = round($total, 2);

// Prepare SQL statement to insert data into the salaries table with the total
$sql = "INSERT INTO salaries (id, month, holidays, bonus, o_t, rateperday, days_of_work, total) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Bind parameters
$stmt->bind_param("isiiiiid", $employee_id, $month, $holidays, $bonus, $o_t, $rateperday, $days_of_work, $total);

// Execute the statement
$stmt->execute();

// Close the statement and connection
$stmt->close();
$conn->close();

// Redirect to a confirmation page or display a success message
header("Location: employee-payslip.php"); // Replace with your confirmation page
?>