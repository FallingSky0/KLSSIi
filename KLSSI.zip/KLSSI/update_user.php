<?php
// Database connection details
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "payroll";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userId = $_POST['id'];
$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$role = $_POST['role'];
$age = $_POST['age'];

// Update user data in the database
$sql = "UPDATE users SET name='$name', username='$username', email='$email', role='$role', age='$age' WHERE id='$userId'";

if ($conn->query($sql) === TRUE) {
    // Redirect back to the user list (or display a success message)
    header("Location: employee.php");
    exit;
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>