<?php
// Database connection details (replace with your actual details)
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "payroll";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get salary data from the 'salaries' table for a specific ID
$id = $_GET['id']; // Get ID from the URL parameter

// Retrieve employee data from the database
$sql = "SELECT * FROM salaries WHERE id = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Get employee name from the 'users' table
    $sql_name = "SELECT name FROM users WHERE id = '$id'";
    $result_name = $conn->query($sql_name);
    $name_row = $result_name->fetch_assoc();

    // Insert data into archive_salaries table (excluding ID)
    $insert_sql = "INSERT INTO archive (name, month, holidays, bonus, o_t, rateperday, days_of_work, total) 
                   VALUES ('" . $name_row['name'] . "', '" . $row['month'] . "', '" . $row['holidays'] . "', '" . $row['bonus'] . "', '" . $row['o_t'] . "', '" . $row['rateperday'] . "', '" . $row['days_of_work'] . "', '" . $row['total'] . "')";

    if ($conn->query($insert_sql) === TRUE) {
        // Delete data from salaries table
        $delete_sql = "DELETE FROM salaries WHERE id = '$id'";
        if ($conn->query($delete_sql) === TRUE) {
            // Redirect to employee-payslip.php
            header("Location: employee-payslip.php");
            exit; // Important to exit after redirect
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "Error inserting record: " . $conn->error;
    }
} else {
    echo "No salary record found for ID: " . $id;
}

// Close the database connection
$conn->close();
?>