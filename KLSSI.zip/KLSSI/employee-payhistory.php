<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment history</title>
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/font.css">
    <style>
        /* ... (Your existing CSS) ... */

        /* Search bar styling */
        #searchInput {
            width: 30%; /* Adjust width as needed (e.g., 25%, 40%) */
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
         body {
            background-image: url('images/bg4.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        
        /* Table styling */
        table {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
            background-color: rgba(247, 191, 22, 0.8); /* Semi-transparent yellow background */
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: rgba(247, 191, 22, 0.8); /* Semi-transparent yellow header */
            color: white;
        }

        table tr:nth-child(even) {
            background-color: rgba(243, 243, 243, 0.8); /* Semi-transparent light gray for even rows */
        }
    </style>
    </style>
<body>

    <!-- Sidebar/menu -->
    <nav class="w3-sidebar w3-black w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
        <div class="w3-container w3-dark-grey">
            <h4>Menu</h4>
        </div>

        <div class="w3-bar-block">
            <dl>
                <dt><a href="home.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a> </dt>
                <dd></dd>
                <dt><a href="employee.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">  Employee  </a></dt>
                <dt><a href="employee-payment.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Payment Parameters</a> </dt>
                <dt><a href="employee-payslip.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Pay slip</a> </dt>
                <dt><a href="employee-payhistory.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white w3-yellow">Payment history</a> </dt>
                <dt><a href="logout.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Log Out</a> </dt>
            </dl>
        </div>
    </nav>

    <!-- Top menu on small screens -->
    <header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
        <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()">☰</a>
        <span>Payroll system</span>
    </header>

    <!-- Overlay effect when opening sidebar on small screens -->
    <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

    <!-- !PAGE CONTENT! -->
    <div class="w3-main" style="margin-left:290px;margin-right:-10px;margin-top: -5px;margin-bottom: 0px">

        <!-- Header -->
        <div class="w3-container">
            <h4></h4>
            <br><br>

            <input type="text" placeholder="Search for name..." id="searchInput" onkeyup="searchPaymentHistory()">

            <br>

            <table id="paymentHistoryTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Month</th>
                        <th>Holidays</th>
                        <th>Bonus</th>
                        <th>Overtime</th>
                        <th>Rate per day</th>
                        <th>Days Of Work</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody id="paymentHistoryTableBody">
                    <!-- Table rows will be populated here by PHP -->
                    <?php
                    // Database connection details
                    $servername = "localhost";
                    $username = "your_username";
                    $password = "your_password";
                    $dbname = "payroll";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Retrieve data from the users table
                    $sql = "SELECT * FROM archive";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row with an edit button
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["name"] . "</td>";
                            echo "<td>" . $row["month"] . "</td>";
                            echo "<td>" . $row["holidays"] . "</td>";
                            echo "<td>" . $row["bonus"] . "</td>";
                            echo "<td>" . $row["o_t"] . "</td>";
                            echo "<td>" . $row["rateperday"] . "</td>";
                            echo "<td>" . $row["days_of_work"] . "</td>";
                            echo "<td>" . $row["total"] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>0 results</td></tr>";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>

    </div>


    <!-- W3.CSS Container -->

    <script>
    // Script to open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }

    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    // Modal Image Gallery
    function onClick(element) {
        document.getElementById("img01").src = element.src;
        document.getElementById("modal01").style.display = "block";
        var captionText = document.getElementById("caption");
        captionText.innerHTML = element.alt;
    }

    // Function to search payment history
    function searchPaymentHistory() {
        const searchTerm = document.getElementById("searchInput").value.toLowerCase();
        const tableBody = document.getElementById("paymentHistoryTableBody");
        const tableRows = tableBody.getElementsByTagName("tr");

        // Loop through each table row
        for (let i = 0; i < tableRows.length; i++) {
            const nameCell = tableRows[i].getElementsByTagName("td")[0];
            const name = nameCell.textContent.toLowerCase();

            // Check if the search term is found in the employee name
            if (name.includes(searchTerm)) {
                tableRows[i].style.display = ""; // Show the row
            } else {
                tableRows[i].style.display = "none"; // Hide the row
            }
        }
    }
    </script>

</body>
</html>