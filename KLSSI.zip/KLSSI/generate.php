<?php
// Include FPDF library
require_once('fpdf/fpdf.php');

// Database connection details (replace with your actual details)
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "payroll";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get salary data from the 'salaries' table for a specific ID
$id = $_GET['id']; // Get ID from the URL parameter

// Retrieve employee data from the database
$sql = "SELECT * FROM salaries WHERE id = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Get employee name from the 'users' table
    $sql_name = "SELECT name FROM users WHERE id = '$id'";
    $result_name = $conn->query($sql_name);
    $name_row = $result_name->fetch_assoc();

    // Calculate deductions
    $philhealth_deduction = $row['total'] * 0.03;
    $sss_deduction = $row['total'] * 0.045;
    $pagibig_deduction = 100.00;
    $total_deductions = $philhealth_deduction + $sss_deduction + $pagibig_deduction;
    $net_pay = $row['total'] - $total_deductions;

    // Calculate total (including bonus and holiday adjustments)
    if (isset($row['bonus']) && $row['bonus'] > 0) {
        if ($row['bonus'] == 1) {
            $bonus_amount = 14736; 
        } else {
            $bonus_amount = $row['bonus']; 
        }
    } else {
        $bonus_amount = 0; // Set bonus to 0 if no value is provided
    }
    $holiday_deduction = $row['rateperday'] * $row['holidays']; // Holiday deduction is rate per day
    $overtime_pay = $row['o_t'] * 76; // Overtime pay is 76 per hour
    $total = ($row['rateperday'] * $row['days_of_work']) + $bonus_amount - $holiday_deduction + $overtime_pay;

    // Update the 'salaries' table with the calculated total
    $update_sql = "UPDATE salaries SET total = '$total' WHERE id = '$id'";
    $update_result = $conn->query($update_sql);

    if ($update_result) {
        // Create PDF object
        $pdf = new FPDF();
        $pdf->AddPage();
        // $pdf->SetEncoding('UTF-8'); // Remove encoding for now

        // Set font
        $pdf->SetFont('Arial', 'B', 16);

        // Receipt title
        $pdf->Cell(0, 10, 'Payroll Receipt', 0, 1, 'C');

        // Company Logo
        $pdf->Image('images/payroll.png', 10, 10, 30); // Replace 'images/your_logo.png' with your logo path

        // Employee information
        $pdf->SetFont('Arial', '', 12);
        $pdf->Ln(20); // Add a line break
        $pdf->Cell(0, 10, 'Employee Name: ' . $name_row['name'], 0, 1);
        $pdf->Cell(0, 10, 'Employee ID: ' . $id, 0, 1);
        $pdf->Cell(0, 10, 'Month: ' . $row['month'], 0, 1);

        // Create table
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetLineWidth(0.5); // Set line width for table borders
        $pdf->SetDrawColor(0, 0, 0); // Set color for table borders

        // Header row
        $pdf->Cell(80, 10, 'Description', 1, 0, 'L');
        $pdf->Cell(40, 10, 'Amount', 1, 1, 'L');

        $pdf->SetFont('Arial', '', 12);

        // Data rows
        $pdf->Cell(80, 10, 'Rate per Day', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($row['rateperday'], 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'Days of Work', 1, 0, 'L');
        $pdf->Cell(40, 10, (int)$row['days_of_work'], 1, 1, 'L'); // Cast to integer

        $pdf->Cell(80, 10, 'Bonus', 1, 0, 'L');
        $pdf->Cell(40, 10, (int)$bonus_amount, 1, 1, 'L');  // Cast to integer

        $pdf->Cell(80, 10, 'Holidays', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($holiday_deduction, 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'Overtime (Hours)', 1, 0, 'L');
        $pdf->Cell(40, 10, (int)$row['o_t'], 1, 1, 'L'); // Cast to integer

        $pdf->Cell(80, 10, 'Overtime Pay', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($overtime_pay, 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'Total Gross Salary', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($total, 2), 1, 1, 'L');

        $pdf->Ln(10);

        // Deductions section
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(80, 10, 'Deductions', 1, 0, 'L');
        $pdf->Cell(40, 10, 'Amount', 1, 1, 'L');

        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(80, 10, 'PhilHealth', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($philhealth_deduction, 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'SSS', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($sss_deduction, 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'Pag-IBIG', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($pagibig_deduction, 2), 1, 1, 'L');

        $pdf->Cell(80, 10, 'Total Deductions', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($total_deductions, 2), 1, 1, 'L');

        // Net Pay
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(80, 10, 'Net Pay', 1, 0, 'L');
        $pdf->Cell(40, 10, number_format($net_pay, 2), 1, 1, 'L');

        // Output PDF
        $pdf->Output('receipt_' . $id . '.pdf', 'D'); // 'D' for download
    } else {
        echo "Error updating total in the database: " . $conn->error;
    }
} else {
    echo "No salary record found for ID: " . $id;
}

// Close the database connection
$conn->close();
?>