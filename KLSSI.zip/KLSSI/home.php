<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome to KLSSI</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/font.css">
    <link rel="icon" type="image/png" href="images/favicon.png">
    <style>
        body, h1, h2, h3, h4, h5 {font-family: "monospace;", sans-serif}
        body {
            font-size: 16px;
            background-image: url("images/bg4.jpg");
            background-size: cover; /* Cover the entire background */
            background-repeat: no-repeat; /* Prevent the background from repeating */
        }
        .w3-half img {margin-bottom: -6px; margin-top: 16px; opacity: 0.8; cursor: pointer;}
        .w3-half img:hover {opacity: 1;}
    </style>
</head>
<body>

<!-- Sidebar/menu -->
<?php
    include('navigation.php');
?>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
    <a href="javascript:void(0)" class="w3-button w3-yellow w3-margin-right" onclick="w3_open()">☰</a>
    <span>Payroll system</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->

    <!-- Header with Image -->
   

<script>
// Script to open and close sidebar
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
    document.getElementById("img01").src = element.src;
    document.getElementById("modal01").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
}
</script>

</body>
</html>