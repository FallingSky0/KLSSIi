<?php
session_start();
include_once('connection.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    if (empty($username) || empty($password)) {
        echo "<script>alert('Please fill both Username and Password');</script>";
        exit;
    } else {
        $sql = "SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
            $name = $row['name'];
            $username = $row['username'];

            $_SESSION['name'] = $name;
            $_SESSION['username'] = $username;
            
            header('location:welcome.php');
            exit;
        } else {
            echo "<script>alert('Invalid Username or Password');</script>";
            exit;
        }
    }
}
?>
